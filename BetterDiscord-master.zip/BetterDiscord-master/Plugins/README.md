# BetterDiscord Plugins - [![Paypal][paypal-logo]][paypal-url] [![GitHub][github-logo]][github-url]

### Plugins

* [Hide Channels](https://github.com/CapnKitten/BetterDiscord/tree/master/Plugins/HideChannels)

[paypal-logo]: https://img.shields.io/static/v1?label=PayPal&message=Donate&style=flat&logo=paypal&color=blue
[paypal-url]: https://paypal.me/capnkitten

[github-logo]: https://img.shields.io/static/v1?label=GitHub&message=Sponsor&style=flat&logo=github&color=black
[github-url]: https://github.com/sponsors/CapnKitten
