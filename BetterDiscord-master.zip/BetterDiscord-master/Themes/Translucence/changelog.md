# Translucence

## Changelog

#### v1.0.6 (18/11/2020)
* Inline replies styled
* Updated elements that Discord changed (If I missed any, please let me know)

#### v1.0.5 (15/10/2020)
* Updated elements that Discord changed (If I missed any, please let me know)

#### v1.0.4.1 (26/09/2020)
* Support for TypingIndicator by l0c4lh057 added
* Updated elements that Discord changed (If I missed any, please let me know)

#### v1.0.4 (23/09/2020)
* Updated elements that Discord changed (If I missed any, please let me know)

#### v1.0 (03/09/2020)
* Initial release
